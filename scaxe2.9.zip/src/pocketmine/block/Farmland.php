<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\math\Vector3;
use pocketmine\item\Tool;
use pocketmine\math\AxisAlignedBB;

class Farmland extends Solid{

	protected $id = self::FARMLAND;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function getName() : string{
		return "Farmland";
	}

	public function getHardness() {
		return 0.6;
	}

	public function getToolType(){
		return Tool::TYPE_SHOVEL;
	}

	protected function recalculateBoundingBox() {
		return new AxisAlignedBB(
			$this->x,
			$this->y,
			$this->z,
			$this->x + 1,
			$this->y + 0.9375,
			$this->z + 1
		);
	}

	public function getDrops(Item $item) : array {
		return [
			[Item::DIRT, 0, 1],
		];
	}
	
	public function onUpdate($type){
        if($type === Level::BLOCK_UPDATE_NORMAL and $this->getSide(Vector3::SIDE_UP)->isSolid()){
            $this->level->setBlock($this, Block::get(Block::DIRT), true);
            return $type;
        }elseif($type === Level::BLOCK_UPDATE_RANDOM){
            if(!$this->canHydrate()){
                if($this->meta > 0){
                    $this->meta--;
                    $this->level->setBlock($this, $this, false, false);
                }else{
                    $this->level->setBlock($this, Block::get(Block::DIRT), false, true);
                }

                return $type;
            }elseif($this->meta < 7){
                $this->meta = 7;
                $this->level->setBlock($this, $this, false, false);

                return $type;
            }
        }

        return false;
    }
	
    protected function canHydrate() : bool{
        if($this->level->getWeather()->getWeather() == Weather::RAINY){
            return true;
        }
        $start = $this->add(-4, 0, -4);
        $end = $this->add(4, 1, 4);
        for($y = $start->y; $y <= $end->y; ++$y){
            for($z = $start->z; $z <= $end->z; ++$z){
                for($x = $start->x; $x <= $end->x; ++$x){
                    $id = $this->level->getBlockIdAt($x, $y, $z);
                    if($id === Block::STILL_WATER or $id === Block::FLOWING_WATER){
                        return true;
                    }
                }
            }
        }

        return false;
    }
}