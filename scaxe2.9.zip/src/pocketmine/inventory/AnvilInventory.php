<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\inventory;

use pocketmine\level\Position;
use pocketmine\Player;

class AnvilInventory extends ContainerInventory{
	
	const TARGET = 0;
	const SACRIFICE = 1;
	const RESULT = 2;
	private $Customitem;
	
	protected $wordsBanned = ["档案馆",".gs","dogmc","狗服","狗头","果实服","iosipa","端口","19132","19133"];
	
	public function __construct(Position $pos){
		parent::__construct(new FakeBlockMenu($this, $pos), InventoryType::get(InventoryType::ANVIL));
	}

	/**
	 * @return FakeBlockMenu
	 */
	public function getHolder(){
		return $this->holder;
	}
	
	
	public function getResultSlotIndex(){
		return self::RESULT;
	}
	
	public function finishRename(Player $player, $type){
		if(!isset($this->Customitem)){
			return;
		}
		if($this->Customitem->hasCustomName()){
			if($this->hasBannedWord($this->Customitem->getCustomName())){
				$player->getServer()->getLogger()->notice($player->getName()."在改名时触发违禁词：".$this->Customitem->getCustomName());
				$item = $this->Customitem->setCustomName("§c检测到违禁词");
				$player->sendMessage("§c改名期间检测到违禁词");
				$this->Customitem = $item;
			}
			if($this->have_emoji($this->Customitem->getCustomName())){
				$item = $this->Customitem->setCustomName("§c不允许emoji");
			}
		}
		$level = $player->getXpLevel();
		$count = 1;
		if($level < $count){
			return false;
		}
		$le = $level - $count;
		$player->setExpLevel($le);
		$this->clearAll();
		$player->getInventory()->addItem($this->Customitem);
		$this->Customitem = null;
	}
	
    public function hasBannedWord($message)
    {
        $wordfound = false;
        $words     = \explode(" ", $message);
        
        if( !isset( $this->wordsBanned ) )
        {
            return $wordfound;
        }
        /* check for the first word banned word occurance */
        foreach( $this->wordsBanned as $bannedWord )
        {
            // breaks on the first inappropriate word encountered
            
            // verify word is set
            if( !isset( $bannedWord[0] ) )
            {
                break;
            }
            // complete word match?
            if( $bannedWord[0] === '\\' )
            {
                $bannedWord = \substr($bannedWord,1);
                foreach( $words as $word )
                {   
                    if( \strcasecmp($word,$bannedWord) === 0 )
                    {
                        $wordfound = true;
                        break 2;
                    }
                } /* foreach( $words as $word */
            }   
                
            // substring match?
            else if( \stripos($message,$bannedWord) !== false )
            {
                $wordfound = true;
                break;
            }
            
        } /* foreach( $this->wordsBanned as $bannedWord ) */
        
        return $wordfound;
        
    }
	
	function have_emoji($str){
		$mat = [];
		preg_match_all('/./u', $str,$mat);
		foreach ($mat[0] as $v){
			if(strlen($v) > 3){
				return true;
			}
		}
		return false;
	}
	
	public function onRename(Player $player, $slot, $sourceItem, $resultItem){
		if(!isset($resultItem)){
			return;
		}
		if(!$resultItem->deepEquals($this->getItem(self::TARGET), true, false, true)){
			//Item does not match target item. Everything must match except the tags.
			return false;
		}
		//$this->clearAll();
		$this->Customitem = $resultItem;
		return true;
		
	}
	
	public function processSlotChange(Transaction $transaction): bool{
		if($transaction->getSlot() === $this->getResultSlotIndex()){
			return false;
		}
		return true;
	}

	public function onClose(Player $who){
		$who->updateExperience();
		parent::onClose($who);

		$this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(1));
		$this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(0));
		$who->usingAnvil = false;
		
		$this->clear(0);
		$this->clear(1);
		$this->clear(2);
	}

}